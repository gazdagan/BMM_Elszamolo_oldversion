<?php

/* 
 * Budapest Mozgásszervi Begánrendelő Napi Elszámolás Projek
 * Gazdag András  * 
 * Mérnök Informatikus * 
 * Programozó Informatikus * 
 */
$telephelymodosítas  = new telephely;
$telephelymodosítas->admin_insert_telephely();
$telephelymodosítas->admin_delete_telephely();
