<?php

/* 
 * Készletnyilvántartás adminisztrációs oldala 
 */

include ("./includes/keszletnyilvantartasClass.php");
echo'<script>';
include ("./js/copyclipboard.js");
include ("./js/ajax.js");
include ("./js/keszletkezeles.js");

echo '</script>';


echo '<h1>BMM készletek</h1>';

$keszletkezeles= new keszletnyilvantartasClass();
echo $keszletkezeles -> Tabmenu();
echo $keszletkezeles ->kategoria_add_popup();