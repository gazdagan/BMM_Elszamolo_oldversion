<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$beveteltipus  = new bevetel_tipusok;
$beveteltipus->admin_insert_beveteltipus();
$beveteltipus->admin_delete_beveteltipus();
