<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$arak_jutalek  = new arak_jutalek();
$arak_jutalek->admin_insert_arak_jutalek();
$arak_jutalek->admin_delete_kezeles_arak_jutalek();

