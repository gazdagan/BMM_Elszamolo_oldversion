<?php
/**
 * Szamla_befogadasClass
 * 
 * Szálák átvételét kezelő osztály
 */

class Szamla_befogadasClass {
    
    public $szamla_szam;
    public $szamlakibocsato_neve;
    /**
     * VisualizeSzamlaBefogadasForm()
     * 
     * számklák átvételét rögzítő form
     */
    public function VisualizeSzamlaBefogadasForm(){
        
        $conn = DbConnect();
        $date = date("y-m-d");
        
        echo'<div class="row">
            <div class="col-sm-4"></div>
            <div class="col-sm-4">
            <div class="panel panel-danger">
        <div class="panel-heading">Kiállított számla átvétele.</div>
        <div class="panel-body">';
        echo '<form method="post" class= "form-horizontal" action="' . $_SERVER["PHP_SELF"] . '?pid=page22">';
        
        echo'<div class="form-group">'
                    . '<label class="col-sm-3 control-label">Átvevő:</label>'
                . '<div class="col-sm-7">'
                    . '<input type="text" class="form-control" name="szamla_atvevo"  placeholder="'.$_SESSION['real_name'].'" value="'.$_SESSION['real_name'].'" disabled>'
                . '</div>'
            . '</div>';
        
        echo'<div class="form-group">'
            . '<label class="col-sm-3 control-label" id="sel1">Szamlázó neve:</label>'
        . '<div class="col-sm-7">'
            . '<input type="text" class="form-control" name="szamla_kibocsato"  placeholder="Szamlakibocsátó megnevezése" required>'        
        . '</div></div>';
            
         
        echo'<div class="form-group">'
                . '<label class="col-sm-3 control-label">Számla sorszáma:</label>'
            . '<div class="col-sm-7">'
                . '<input type="text" class="form-control" name="szamla_sorszam"  placeholder="ABCDE 123456" required>'        
            . '</div></div>';     
        
        //kp megjegyzes
        echo'<div class="form-group">'
        . '<label class="col-sm-3 control-label">Megjegyzés:</label>'
        . '<div class="col-sm-7">'
        . '<input type="text" class="form-control" name="szamla_megjegyzes"  placeholder="Megjegyzés" >'
        . '</div></div>';
               
        // ok gomb
        echo'<div class="form-group">'
        . '<label class="col-sm-3 control-label"></label>'
        . '<div class="col-sm-7">';
        echo'<button type = "submit" value = "Submit" type = "button" class = "btn btn-success">Rendben</button>'
        . '</div></div>';

        echo '</form>';

        echo '</div>
        <div class="panel-footer">Számal befogadása orvostól kezelőtől stb.....';
        
        echo '</div>
        </div></div>
        <div class="col-sm-4"></div>
        </div>';
        
       //$this->Visualize_All_Szamla_Table_User();
         
    }
    
    public function user_post_szamlabefogadas (){
         
        if (isset($_POST["szamla_kibocsato"]) && isset($_POST["szamla_sorszam"])) {
                     
            $conn = DbConnect();
            
            $szamla_atvevo = $_SESSION['real_name'];
            $szamla_telphely  = $_SESSION['set_telephely'];
            $szamla_atvetdate = $date = date("y-m-d");
            $szamla_kibocsato = test_input($_POST["szamla_kibocsato"]);
            $szamla_sorszam = test_input($_POST["szamla_sorszam"]);
            $szamla_megjegyzes = test_input($_POST["szamla_megjegyzes"]);
            $szamla_torolt =  0;
            
          
                $sql = "INSERT INTO szamla_befogadas (szamla_telephely, szamla_atvevo,szamla_atvetdate,szamla_kibocsato,szamla_sorszam,szamla_megjegyzes,szamla_torolt)
                                            VALUES ('$szamla_telphely','$szamla_atvevo','$szamla_atvetdate','$szamla_kibocsato','$szamla_sorszam','$szamla_megjegyzes','$szamla_torolt')";

                if (mysqli_query($conn, $sql)) {
                    // echo "New record created successfully";
                } else {
                    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
                }
                          
            mysqli_close($conn);
        }
        
        
    }
    
    function Visualize_All_Szamla_Table_User($user) {
        $conn = DbConnect();
        
          $atvevo_neve = $_SESSION['real_name'];
          $szamla_telephely = $_SESSION['set_telephely'];
          $today_date = date("y-m-d");
          $cimsor; 
        if($user == "napiosszes"){
        
        $sql = "SELECT * FROM szamla_befogadas WHERE szamla_atvetdate = '$today_date' AND szamla_telephely ='$szamla_telephely' AND szamla_torolt = '0'";
        $cimsor = "Napi összes átvett számla:";
        }else{
        $sql = "SELECT * FROM szamla_befogadas WHERE szamla_atvetdate = '$today_date' AND szamla_telephely ='$szamla_telephely' AND szamla_torolt = '0' AND szamla_atvevo = '$atvevo_neve'";
        $cimsor = "$atvevo_neve   átvett számlái:";
               
        }
        $result = $conn->query($sql);

        echo'<div class="">
                <table class="table table-striped">
                <thead>
                    <tr><th>'.$cimsor.'</th></tr>
                    <tr>
                      <th>No.:</th>
                      <th>Átvevő</th>
                      <th>Kibocsátó</th>
                      <th>Számla sorszám</th>
                      <th>Megjegyzés</th>
                    </tr>
                  </thead><tbody>';
            
          if ($result->num_rows > 0) {    
            while ($row = $result->fetch_assoc()) {
                echo "<tr><td>"
                . $row["szamla_id"] . "</td><td> "
                . $row["szamla_atvevo"] . "</td><td>"
                . $row["szamla_kibocsato"] . "</td><td>"
                . $row["szamla_sorszam"] . "</td><td>"   
                . $row["szamla_megjegyzes"] . "</td></tr>" 
               ;
            }
        } else {
            echo "<tr><td>Nincs rögzített adat</td></tr>";
        }
        echo "</tbody></table></div>";
        
       
        mysqli_close($conn);
    }
    
    public function Visualize_Delete_Szamla_Table(){
        $conn = DbConnect();
        
          $atvevo_neve = $_SESSION['real_name'];
          $szamla_telephely = $_SESSION['set_telephely'];
          $today_date = date("y-m-d");
        
        $sql = "SELECT * FROM szamla_befogadas WHERE szamla_atvetdate = '$today_date' AND szamla_telephely ='$szamla_telephely' AND szamla_torolt = '0' AND szamla_atvevo = '$atvevo_neve'";
        $result = $conn->query($sql);

        echo '<form action="' . $_SERVER['PHP_SELF'] . '?pid=page25" method="post">';
            echo'<div class="container">
                    <h2>Átvett számlák tölése:</h2>
                <table class="table table-striped">
                <thead>
                    <tr>
                        <th>No.:</th>
                        <th>Átvevő</th>
                        <th>Kibocsátó</th>
                        <th>Számla sorszám</th>
                        <th>Megjegyzés</th>
                        <th>Törléstre kijelölt</th>
                    </tr>
                  </thead><tbody>';
            
          if ($result->num_rows > 0) {    
            while ($row = $result->fetch_assoc()) {
                echo "<tr><td>"
                . $row["szamla_id"] . "</td><td> "
                . $row["szamla_atvevo"] . "</td><td>"
                . $row["szamla_kibocsato"] . "</td><td>"
                . $row["szamla_sorszam"] . "</td><td>"   
                . $row["szamla_megjegyzes"] . "</td><td>" 
                . '<input type="radio" name="delete_szamla_id" value="' . $row["szamla_id"] . '"></td></tr>'
                ;
            }
        } else {
            echo "<tr><td>Nincs rögzített adat</td></tr>";
        }
        echo '<tr><td></td><td></td><td></td><td></td><td></td><td><button type = "submit" value = "Submit" type = "button" class = "btn btn-danger">Töröl</button></td></tr>';
        echo "</tbody></table></form>";
        
       
        mysqli_close($conn);
    }
    
    function User_Post_Delete_Szamla()
    {
        if (isset($_POST['delete_szamla_id'])) {
            $deleteid = $_POST['delete_szamla_id'];
            $conn = DbConnect();

            $sql = "UPDATE szamla_befogadas SET szamla_torolt=1 WHERE szamla_id='$deleteid'";

            if (mysqli_query($conn, $sql)) {
                // echo "New record created successfully";
            } else {
                echo "Error: " . $sql . "<br>" . mysqli_error($conn);
            }
            mysqli_close($conn);
        }
    }


}
