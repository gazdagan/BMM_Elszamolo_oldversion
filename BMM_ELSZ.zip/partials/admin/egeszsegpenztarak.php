<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$epmodosítas  = new egeszsegpenztar;
$epmodosítas->admin_insert_egeszsegpenztar();
$epmodosítas->admin_delete_egeszsegpenztar();

