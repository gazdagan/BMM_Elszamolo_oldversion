<?php

/* 
 * Medical Pluss Jft Segédeszköz eladás
 * 
 * 
 */

$segedszkoz = new SegedeszkozClass();
$segedszkoz->Visualize_New_Segedeszkoz_Form();
$segedszkoz->Visulaize_Segedeszkoz_Eladasok();
