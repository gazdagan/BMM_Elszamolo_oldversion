<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$daily_list_szamlak = new User_Select_NapiElsz;
$daily_list_szamlak ->user_select_medicalplus_beveteltipusok();

$segedszkoz = new SegedeszkozClass();
$segedszkoz->Visulaize_Segedeszkoz_Eladasok();

?>
