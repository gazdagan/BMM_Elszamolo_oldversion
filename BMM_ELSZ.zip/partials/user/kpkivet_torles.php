<?php
/**
 *Napi kp kivét törlése frontend táblázata 
 */

$kpkivetform = new Keszpenz_kivetClass;
$kpkivetform->Visualize_Delete_Kpkivet_Table();

?>