<?php

/* 
 * napi elszámolás adatainak módosítása
 */

$updatetable = new napi_elszamolas;
$updatetable->user_select_delete_dbrow();