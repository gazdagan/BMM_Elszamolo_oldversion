<?PHP

$kpszamlatorles = new Szamla_befogadasClass;
$kpszamlatorles -> Visualize_Delete_Szamla_Table();

?>