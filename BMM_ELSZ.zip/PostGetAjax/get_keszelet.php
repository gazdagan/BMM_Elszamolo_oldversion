<?php

/* 
 készlet adatok lekérdezése eladéskor
 */

require_once ( "../includes/DbConnect.inc.php");
include ( "../includes/Inputvalidation.inc.php");
include ("../includes/keszletnyilvantartasClass.php");


// azok a termékkategóriák amelyek az adott telephelyen elérhetőek
if (isset($_GET["keszlet_telephely_neve"])){
$html="";
$conn = DbConnect();
$html ='<div class="form-group" id="selectkeszletkategoria"><label>Készlet kategóriák:</label>';

$telephely = $_GET["keszlet_telephely_neve"];


$sql1 = "SELECT * FROM aru_kategoria";
$result1 = $conn->query($sql1);

if ($result1->num_rows > 0) {
    // output data of each row
    while($row = $result1->fetch_assoc()) {
          $html .= '<div class="radio"><label><input type="radio" name="kategoria" id="kat_id'.$row["kategoria_id"].'" date-telephely = "'.$telephely.'"  date-kategorianame="'.$row["kategoria_neve"].'" data-kategoriaid="'.$row["kategoria_id"].'" onclick="keszlet_tetelek(this.id)">' .$row["kategoria_neve"].'</label></div>';
    }
    $html .= "</div>";
    echo $html;
} else {
    echo "0 results";
}

$conn->close();
   
}

if (isset($_GET["kategoria_id"]) AND isset($_GET["keszlet_raktar"])){
$html="";
$conn = DbConnect();
$html ='<div class="form-group" id="selectkeszlettetelek"><label>Készlet tételek:</label>';

$kategoria_id =  $_GET["kategoria_id"];
$keszlet_raktar = $_GET["keszlet_raktar"];


$html .= '<table class="table table-hover">
                        <thead>
                        <tr>
                          <th>Áru neve / Méret</th>
                          <th>Eladási Ár</th>
                          <th>Vényes Ár</th>
                          <th>Akciós Ár</th>
                          <th style="text-align:right;">Készlet db</th>
                        </tr>
                      </thead><tbody>';

$sql = "SELECT * FROM aru_cikktorzs WHERE aru_kategoria = '$kategoria_id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
              
            $aru_id = $row["aru_id"];
            
            $sql1 = "SELECT * FROM aru_keszlet INNER JOIN aru_cikktorzs ON aru_cikktorzs.aru_id = aru_keszlet.keszlet_aru_id WHERE keszlet_aru_id = '$aru_id' AND keszlet_raktar = '$keszlet_raktar' ORDER BY keszlet_id DESC LIMIT 1";
            $result1 = $conn->query($sql1);
          
            if ($result1->num_rows > 0) {
                // output data of each row
                while($row1 = $result1->fetch_assoc()) {
                   
                    if ($row1["keszlet_db"] <= 0){$class="danger";}else{$class="";}
                    
                    $html .= '<tr class="'.$class.'">'
                               .'<td>'.$row1["aru_name"].' / '.$row1["aru_meret"].'</td>'.
                               '<td><label><input name="cikk" type="radio" id="'.$row1["keszlet_id"].'ear"  data-ar="'.$row1["aru_eladasi_ar"].'" data-cikk="'.$row1["aru_name"].' / '.$row1["aru_meret"].'" data-cikkid="'.$aru_id.'" onclick="keszlet_eladas(this.id)"> '.$row1["aru_eladasi_ar"].' Ft </label></td>'.
                               '<td><label><input name="cikk" type="radio"  id="'.$row1["keszlet_id"].'var" data-ar="'.$row1["aru_venyes_ar"].'" data-cikk="'.$row1["aru_name"].' / '.$row1["aru_meret"].'"  data-cikkid="'.$aru_id.'" onclick="keszlet_eladas(this.id)"> '.$row1["aru_venyes_ar"].' Ft </label></td>'.
                               '<td><label><input name="cikk" type="radio"  id="'.$row1["keszlet_id"].'aar" data-ar="'.$row1["aru_akcios_ar"].'" data-cikk="'.$row1["aru_name"].' / '.$row1["aru_meret"].'"  data-cikkid="'.$aru_id.'" onclick="keszlet_eladas(this.id)"> '.$row1["aru_akcios_ar"].' Ft </label></td>'.
                               '<td style="text-align:right;">'.$row1["keszlet_db"].' db</td>'.
                            '</tr>';
                    
                    
                }
            } else {
               // $html .= "<tr> nincs készleten Aru ID: " .$aru_id."</tr>";
            }  
            
         
           
        }
    } else {
        // $html .= "<tr> nincs készleten Kat ID: " .$kategoria_id."</tr>";
    }
 $html .= "</table></div>";
 $html .='<div class="btn-group-vertical"><button type="button" class="btn btn-warning btn-xs" value="egyedi_ar" onclick="egyedi_arak_szolg(this.value)"><i class="fa fa fa-money" aria-hidden="true"></i>  Egyedi árazás       </button><button type="button" class="btn btn-warning btn-xs" value="egyedi_szolg" onclick="egyedi_arak_szolg(this.value)"><i class="fa fa-product-hunt" aria-hidden="true"></i>   Egyedi szolgáltatás </button></div>';    

 echo $html;
$conn->close();
   
}