/* 
 * xls kimenta a id val kijelőlt inputról
 * 
 */


$(function(){
    $("#tabletoExel").click(function(){
       $("#riport").table2ecel(); 
    });
});