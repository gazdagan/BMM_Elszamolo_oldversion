/* 
 *számlák postázásának rögzítése post 
 */


function postAjax(url, data, success) {
    
     var params = typeof data == 'string' ? data : Object.keys(data).map(
            function(k){ return encodeURIComponent(k) + '=' + encodeURIComponent(data[k]) }
        ).join('&');

    var xhr = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject("Microsoft.XMLHTTP");
    xhr.open('POST', url);
    xhr.onreadystatechange = function() {
        if (xhr.readyState>3 && xhr.status==200) { success(xhr.responseText); 
        
        }
    };
    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.send(params);
    return xhr;
}

function Postazas(id){
    console.log("postazas: ",id);
    
    var adatok = {
        id_szamla:"",
        event: "add",
        date: ""
       };    
       
    postazas_date = 'postazas_date' + id;
  
    adatok.id_szamla = id;   
    adatok.date = document.getElementById(postazas_date).value;
    
    postAjax("./PostGetAjax/post_postazas.php", adatok, function(data){ console.log(data); });
   
   tabeledate = 'date' + id; 
   
   var d = new Date();
   var y = d.getFullYear();
   var m = d.getMonth()+1;
   if (m < 10) {m = '0' + m;}
   var d = d.getDate();
   
   document.getElementById(id).className = "info";
   document.getElementById(tabeledate).innerHTML = adatok.date;
   

}

function Postazas_torles (id){
    console.log("postazas_torlés: ",id);
    
    var adatok = {
        id_szamla:"",
        event: "erease"
       };    
       
    adatok.id_szamla = id;   
    postAjax("./PostGetAjax/post_postazas.php", adatok, function(data){ console.log(data); });
    
    tabeledate = 'date' + id; 

    document.getElementById(id).className = "warning";
    document.getElementById(tabeledate).innerHTML = "";
           
    // window.location.reload();
}


function Bank_date(id){
    console.log("bank: ",id);
    
    var adatok = {
        id_szamla:"",
        event: "add",
        date: ""
       };    
       
    postazas_date = 'bank_date' + id;
  
    adatok.id_szamla = id;   
    adatok.date = document.getElementById(postazas_date).value;
    
    postAjax("./PostGetAjax/post_bank.php", adatok, function(data){ console.log(data); });
   
   tabeledate = 'bank' + id; 
   
   var d = new Date();
   var y = d.getFullYear();
   var m = d.getMonth()+1;
   if (m < 10) {m = '0' + m;}
   var d = d.getDate();
   
   document.getElementById(id).className = "info";
   document.getElementById(tabeledate).innerHTML = adatok.date;
   

}

function Bank_torles (id){
    console.log("bank_torlés: ",id);
    
    var adatok = {
        id_szamla:"",
        event: "erease"
       };    
       
    adatok.id_szamla = id;   
    postAjax("./PostGetAjax/post_bank.php", adatok, function(data){ console.log(data); });
    
    tabeledate = 'bank' + id; 

    document.getElementById(id).className = "warning";
    document.getElementById(tabeledate).innerHTML = "";
           
    // window.location.reload();
}